from .engine.detection_engine import detect_ip

__all__ = ["detect_ip"]